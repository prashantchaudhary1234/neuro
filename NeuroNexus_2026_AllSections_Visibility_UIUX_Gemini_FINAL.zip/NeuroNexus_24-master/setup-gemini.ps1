# NeuroNexus - secure Gemini API setup
# Run this once in PowerShell from the project root.
$secure = Read-Host "Paste your Gemini API key" -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
  $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
  @(
    "GEMINI_API_KEY=$key"
    "GEMINI_MODEL=gemini-2.5-flash"
    "PORT=8787"
  ) | Set-Content -Encoding utf8 .env
  Write-Host "Gemini key configured in .env. Keep .env private and never commit it."
} finally {
  if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}
