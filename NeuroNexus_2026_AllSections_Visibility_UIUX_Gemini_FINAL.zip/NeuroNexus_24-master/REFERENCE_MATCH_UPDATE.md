# SRM Reference UI Match + Interactive 3D Update

This build keeps the NeuroNexus clinical modules/backend while aligning the ICU command-center presentation with the supplied SRM Hospital Supporter System deployment as a visual reference.

## 3D ward interaction
- Drag with the mouse/touch pointer to rotate the ICU digital twin.
- Drag vertically to tilt the scene.
- Use the mouse wheel/trackpad scroll to zoom in and out.
- Use `+`, `-`, and `Reset View` for camera controls.
- `360° Orbit` runs the automatic orbit animation.
- The 2D view disables the 3D camera interaction.

The reference deployment was used as a visual reference; its source code was not extracted.
