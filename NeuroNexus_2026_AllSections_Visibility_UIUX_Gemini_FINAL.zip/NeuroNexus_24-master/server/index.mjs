import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { URL } from 'node:url';

// Lightweight .env loader so the backend also works on Node versions without --env-file.
const envPath = path.resolve(process.cwd(), '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim().replace(/^\"|\"$/g, '');
    if (key && !process.env[key]) process.env[key] = value;
  }
}
import { GoogleGenAI, Type } from '@google/genai';

const PORT = Number(process.env.PORT || 8787);
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.API_KEY || '';
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const ai = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

function json(res, status, payload) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});
  res.end(JSON.stringify(payload));
}
function readBody(req) {
  return new Promise((resolve,reject)=>{ let raw=''; req.on('data',c=>{raw+=c;if(raw.length>1_000_000){reject(new Error('Request body is too large.'));req.destroy();}}); req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{});}catch{reject(new Error('Invalid JSON body.'));}}); req.on('error',reject); });
}
async function geminiText({systemInstruction,contents,schema}) {
  if(!ai) throw new Error('GEMINI_API_KEY is not configured on the backend.');
  const config={systemInstruction,temperature:0.25};
  if(schema){config.responseMimeType='application/json';config.responseSchema=schema;}
  const response=await ai.models.generateContent({model:MODEL,contents,config});
  return response.text || '';
}
function parseJson(text){try{return JSON.parse(text);}catch{const m=text.match(/\{[\s\S]*\}/);if(m)return JSON.parse(m[0]);throw new Error('Gemini returned an unexpected response format.');}}
async function handle(req,res){
  if(req.method==='OPTIONS') return json(res,204,{});
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(req.method==='GET'&&url.pathname==='/') {
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
    res.end(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NeuroNexus AI Backend</title><style>body{margin:0;background:#06111f;color:#f4f8ff;font-family:Inter,system-ui,sans-serif;display:grid;place-items:center;min-height:100vh}.card{max-width:680px;margin:24px;padding:32px;border:1px solid #123452;border-radius:20px;background:linear-gradient(145deg,#0b1d31,#07121f);box-shadow:0 20px 60px #0008}h1{margin:0 0 8px;color:#00d9ff}p{color:#9fb2c7;line-height:1.6}.ok{color:#54f0b0;font-weight:700}.links{display:flex;gap:12px;flex-wrap:wrap;margin-top:20px}a{color:#fff;text-decoration:none;border:1px solid #087cff;padding:10px 14px;border-radius:10px;background:#087cff22}</style></head><body><main class="card"><h1>NEURO<span style="color:#54f0b0">NEXUS</span></h1><h2>AI Backend is Running</h2><p class="ok">● Server online on port ${PORT}</p><p>Gemini: <strong>${GEMINI_API_KEY ? 'Configured' : 'Not configured'}</strong></p><p>This port serves the AI API. The React dashboard runs separately through Vite.</p><div class="links"><a href="/api/health">API Health</a><a href="http://localhost:3000">Open NeuroNexus Dashboard</a></div></main></body></html>`);
    return;
  }
  if(req.method==='GET'&&url.pathname==='/api/health') return json(res,200,{ok:true,geminiConfigured:Boolean(GEMINI_API_KEY),model:MODEL,frontend:'http://localhost:3000'});
  if(req.method!=='POST'||!url.pathname.startsWith('/api/ai/')) return json(res,404,{error:'Route not found.'});
  try{
    const body=await readBody(req);
    if(url.pathname==='/api/ai/analyze-patient'){
      const schema={type:Type.OBJECT,properties:{riskLevel:{type:Type.STRING},riskScore:{type:Type.NUMBER},summary:{type:Type.STRING},keyFactors:{type:Type.ARRAY,items:{type:Type.STRING}},recommendedMonitoring:{type:Type.ARRAY,items:{type:Type.STRING}},explanation:{type:Type.STRING}},required:['riskLevel','riskScore','summary','keyFactors','recommendedMonitoring','explanation']};
      const result=parseJson(await geminiText({systemInstruction:'You are an ICU clinical decision-support assistant. Explain the supplied retrospective telemetry and model output. Do not diagnose, prescribe, invent missing data, or override the supplied model risk score. Keep recommendations limited to monitoring considerations for a clinician to review. Clearly state uncertainty.',contents:`Analyze this supplied ICU case. Preserve the model risk score exactly; explain what the supplied data may indicate.\n\n${JSON.stringify(body,null,2)}`,schema}));
      return json(res,200,result);
    }
    if(url.pathname==='/api/ai/clinical-summary'){
      const source=body.notes||body; const text=await geminiText({systemInstruction:'You are a clinical documentation assistant. Summarize only the information supplied by the application. Do not add diagnoses, medications, treatments, or facts that are not present. Label the result as AI Clinical Decision Support and recommend clinician verification.',contents:`Create a concise structured ICU clinical summary from this supplied data:\n\n${typeof source==='string'?source:JSON.stringify(source,null,2)}`});
      return json(res,200,{summary:text,text});
    }
    if(url.pathname==='/api/ai/explain-alert'){
      const schema={type:Type.OBJECT,properties:{summary:{type:Type.STRING},explanation:{type:Type.STRING},riskScore:{type:Type.NUMBER},keyFactors:{type:Type.ARRAY,items:{type:Type.STRING}}},required:['summary','explanation','riskScore','keyFactors']};
      const result=parseJson(await geminiText({systemInstruction:'Explain an existing ICU alert using only the provided alert data. Do not invent a diagnosis or treatment. Return the supplied risk score unchanged and frame the response as clinical decision support.',contents:JSON.stringify(body,null,2),schema}));
      return json(res,200,result);
    }
    if(url.pathname==='/api/ai/triage'){
      const schema={type:Type.OBJECT,properties:{score:{type:Type.INTEGER},justification:{type:Type.STRING}},required:['score','justification']};
      const result=parseJson(await geminiText({systemInstruction:'You are a triage decision-support assistant. Analyze only the supplied complaint, age, and gender. Return a 1-100 triage risk estimate with a concise justification. This is not a diagnosis and must be reviewed by clinical staff.',contents:JSON.stringify(body,null,2),schema}));
      result.score=Math.max(1,Math.min(100,Number(result.score)||50)); return json(res,200,result);
    }
    if(url.pathname==='/api/ai/recommend-department'){
      const schema={type:Type.OBJECT,properties:{department:{type:Type.STRING},explanation:{type:Type.STRING}},required:['department','explanation']};
      const result=parseJson(await geminiText({systemInstruction:'You are a hospital routing decision-support assistant. Recommend a department based only on the supplied information. Do not diagnose or prescribe. State that a clinician should verify the routing recommendation.',contents:JSON.stringify(body,null,2),schema})); return json(res,200,result);
    }
    if(url.pathname==='/api/ai/ask'){
      const answer=await geminiText({systemInstruction:'You are a clinical decision-support assistant. Answer questions using only the supplied patient context. Do not invent missing information, diagnose autonomously, or prescribe treatment. Clearly identify uncertainty and advise clinician verification when appropriate.',contents:`PATIENT CONTEXT:\n${JSON.stringify(body.patient||{},null,2)}\n\nQUESTION:\n${body.question||''}`}); return json(res,200,{answer});
    }
    return json(res,404,{error:'AI route not found.'});
  }catch(error){console.error('[NeuroNexus backend]',error);return json(res,500,{error:error instanceof Error?error.message:'Internal server error.'});}
}
http.createServer(handle).listen(PORT,'0.0.0.0',()=>{console.log(`NeuroNexus AI backend running on http://localhost:${PORT}`);console.log(`Gemini: ${GEMINI_API_KEY?'configured':'NOT configured (set GEMINI_API_KEY in .env)'}`);});
