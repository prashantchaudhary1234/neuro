import fs from 'node:fs';
import readline from 'node:readline';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = q => new Promise(resolve => rl.question(q, resolve));
const key = (await ask('Paste your Gemini API key (input will be visible in this terminal): ')).trim();
rl.close();
if (!key || /YOUR_GEMINI_API_KEY|PASTE_YOUR|CHANGE_ME/i.test(key)) {
  console.error('No valid key was supplied. Nothing was changed.');
  process.exit(1);
}
const model = 'gemini-2.5-flash';
const env = `GEMINI_API_KEY=${key}\nGEMINI_MODEL=${model}\nPORT=8787\n`;
fs.writeFileSync('.env', env, { mode: 0o600 });
console.log('Gemini configuration written to .env');
console.log('The .env file is ignored by Git and is not included in the project ZIP.');
