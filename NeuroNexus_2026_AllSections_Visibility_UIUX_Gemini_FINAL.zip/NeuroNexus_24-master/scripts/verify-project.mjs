import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'package.json','index.html','index.tsx','App.tsx','vite.config.ts',
  'server/index.mjs','services/geminiService.ts','types.ts',
  'components/clinical_intelligence/ICUWardCommandCenter.tsx',
  'components/clinical_intelligence/ICUWardCommandCenter.css',
  'ml/train.py','ml/predict.py','ml/preprocessing.py'
];
const missing = required.filter(file => !fs.existsSync(path.join(root, file)));
if (missing.length) {
  console.error('Missing required project files:');
  missing.forEach(file => console.error(` - ${file}`));
  process.exit(1);
}
const env = fs.existsSync('.env') ? fs.readFileSync('.env','utf8') : '';
const keyLine = env.split(/\r?\n/).find(line => line.startsWith('GEMINI_API_KEY=')) || '';
const configured = keyLine && !/YOUR_GEMINI_API_KEY|PASTE_YOUR|CHANGE_ME/i.test(keyLine.split('=').slice(1).join('=').trim());
console.log('✓ Required project files present');
console.log(`✓ Gemini key: ${configured ? 'configured locally' : 'not packaged (secure default)'}`);
console.log('✓ Project verification complete');
