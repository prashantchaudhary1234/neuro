# NeuroNexus 2026 Premium UI Update

Updated the portal UI to use one consistent premium clinical command-center visual system across role dashboards and the landing page.

## Included
- Premium dark navy + royal violet + cyan visual language
- Animated grid and scan-line background
- Animated sidebar top rail
- Consistent active/inactive navigation states
- Higher text contrast and cleaner typography
- Premium glass-style cards with hover lift and glow
- Staggered page/card entrance animations
- Role selection cards redesigned with icon containers, hover sheen and glow
- Unified header/search/user-session styling
- Dark data tables and form controls for dashboard consistency
- Responsive behavior for tablet/mobile
- Reduced-motion accessibility support

## Main updated files
- `index.css`
- `components/LoginView.tsx`
- `components/nurse/NurseSidebar.tsx`
- `components/nurse/NurseDashboard.tsx`
- `components/doctor_dashboard/DoctorDashboard.tsx`
- `components/intern_dashboard/InternDashboard.tsx`
- `components/receptionist/ReceptionistDashboard.tsx`
- `components/patient_dashboard/PatientDashboard.tsx`

The Gemini/Vercel API structure from the previous Vercel-ready package is preserved.
