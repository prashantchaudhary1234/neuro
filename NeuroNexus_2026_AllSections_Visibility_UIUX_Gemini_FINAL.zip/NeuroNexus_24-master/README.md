# NeuroNexus — Clinical Intelligence + ICU Digital Twin

A complete React/TypeScript hospital management and ICU early-warning prototype with a premium animated command-center UI, Node.js Gemini gateway, and Python ML pipeline.

## Quick start

```bash
npm install
node scripts/setup-gemini.mjs
npm run server
```

Open a second terminal:

```bash
npm run dev
```

Or use `start.ps1` / `start.sh`.

- Frontend: http://localhost:3000
- Backend: http://localhost:8787
- Health: http://localhost:8787/api/health

See `PROJECT_COMPLETE.md` for the full architecture, modules, Gemini setup, ML workflow, and security notes.
