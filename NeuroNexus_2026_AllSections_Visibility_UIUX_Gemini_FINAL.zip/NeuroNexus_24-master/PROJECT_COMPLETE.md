# NeuroNexus — Complete Project Guide

NeuroNexus is a React + TypeScript hospital/ICU clinical-intelligence prototype with a Vite frontend, Node.js Gemini gateway, curated ICU/clinical data, and an included Python ML pipeline.

## 1. Architecture

```text
Browser
  │
  ├── React + TypeScript + Vite
  │     ├── Hospital dashboard
  │     ├── Role-based portals
  │     ├── ICU Digital Twin / 360° scene
  │     ├── Patient risk views
  │     └── Clinical analytics
  │
  └── /api/*
          │
          ▼
      Node.js backend :8787
          │
          └── Google Gemini API

Python ML pipeline
  ├── preprocessing.py
  ├── features.py
  ├── train.py
  ├── predict.py
  └── evaluation + saved demo models
```

## 2. Start from a clean machine

Requirements:
- Node.js 20+ recommended
- npm 10+
- Python 3.10+ only if you want to retrain/use the ML pipeline
- A Gemini API key for live Gemini features

Install frontend/backend dependencies:

```bash
npm install
```

Configure Gemini locally:

```bash
node scripts/setup-gemini.mjs
```

The key is stored in `.env`. The repository ignores `.env`, so a real credential is never distributed with the project.

## 3. Run everything

Two-terminal method:

```bash
npm run server
```

and:

```bash
npm run dev
```

Or use the provided launcher:

PowerShell:

```powershell
.\start.ps1
```

Linux/macOS:

```bash
./start.sh
```

Frontend: `http://localhost:3000`
Backend: `http://localhost:8787`
Health: `http://localhost:8787/api/health`

## 4. Gemini configuration

`.env`:

```env
GEMINI_API_KEY=YOUR_KEY_HERE
GEMINI_MODEL=gemini-2.5-flash
PORT=8787
```

Gemini requests are made by the Node backend. The browser does not receive the secret key.

Implemented API routes:

- `POST /api/ai/analyze-patient`
- `POST /api/ai/clinical-summary`
- `POST /api/ai/explain-alert`
- `POST /api/ai/triage`
- `POST /api/ai/recommend-department`
- `POST /api/ai/ask`

## 5. UI/UX

The current design is a dark clinical command-center system with:

- glassmorphism panels
- cyan/blue/green clinical status accents
- responsive sidebar/navigation
- animated cards and live indicators
- ICU ward digital twin
- one-shot 360° orbit animation
- zoom/perspective support
- alert/risk visual hierarchy
- responsive layouts
- reduced-motion accessibility handling

## 6. Clinical Intelligence modules

The project includes:

- ICU Early Warning
- Patient Risk Detail
- Telemetry Replay
- Alert Center
- Model Performance
- Alert Analytics
- Data Quality
- AI clinical summaries
- AI alert explanations
- AI triage support
- Department routing support

## 7. Hospital modules

The existing application also contains registration, complaints, digital vitals, e-prescription, pharmacy, drug information, laboratory, billing, emergency/legal workflows, ICU/ward management, nursing/doctor deployment, medical gas, patient feedback, discharge transcription, compliance, housekeeping, IT, mortuary, transplant, CSSD, laundry, HR, finance, insurance, purchasing, medication-error reporting, and NCD prevention modules.

## 8. ML pipeline

The `ml/` directory contains the existing early-warning pipeline, including preprocessing, feature generation, training, prediction, evaluation metrics, thresholds, feature importance, curated demo patients, and saved model artifacts.

Example:

```bash
python ml/dataset_report.py
python ml/train.py
python ml/predict.py --help
```

Only retrain when the required dataset/dependencies are available.

## 9. Verification

Run:

```bash
npm run verify
```

This checks that the important application, backend, clinical-intelligence, and ML files exist and reports whether a local Gemini key is configured.

## 10. Important security note

This is a demonstration/academic clinical software prototype. It must not be treated as a production medical-record or autonomous clinical-decision system.

Never commit:
- `.env`
- API keys
- real patient information
- production credentials

AI output is decision support and must be reviewed by qualified clinical staff.
