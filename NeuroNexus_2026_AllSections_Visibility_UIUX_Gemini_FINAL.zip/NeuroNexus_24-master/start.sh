#!/usr/bin/env bash
set -e
printf '\n=== NeuroNexus Clinical Intelligence ===\n'
if [ ! -f .env ]; then
  echo 'No .env found. Run: node scripts/setup-gemini.mjs'
fi
npm run server &
SERVER_PID=$!
trap 'kill $SERVER_PID 2>/dev/null || true' EXIT
sleep 2
npm run dev
