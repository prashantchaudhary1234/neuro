# NeuroNexus 2026 — Responsive Role Portals + Live Gemini AI

## UI
- Role selection cards are responsive: 3 columns desktop, 2 tablet, 1 phone.
- Doctor, Nurse Head, Receptionist, Intern, Patient and Others remain clearly visible and touch-friendly.
- Portal pages receive a consistent premium dark clinical visual system with responsive spacing.
- Tables and wide content remain usable on phone/tablet through controlled horizontal scrolling.

## Live Gemini
Doctor, Nurse, Receptionist, Intern and Admin portals now include a Neuro AI Assistant console.
The console calls `POST /api/ai/ask` and displays the actual backend response. It does not fabricate a local AI answer when Gemini is unavailable.

Set these server environment variables:

```env
GEMINI_API_KEY=your_actual_google_gemini_api_key
GEMINI_MODEL=gemini-3.8-flash
```

The backend default is `gemini-3.8-flash`. Gemini 2.5 Flash remains supported by Google but Google currently recommends newer models for new projects.

## Verification
- TypeScript/TSX syntax checked for all changed files.
- ZIP integrity checked after packaging.
- Full Vite build was not run in the packaging environment because the extracted `node_modules` did not contain the Vite executable. Run `npm install` then `npm run build` locally.
