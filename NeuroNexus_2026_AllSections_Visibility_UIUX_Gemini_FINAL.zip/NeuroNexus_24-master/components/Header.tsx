import React, { useState } from 'react';

interface HeaderProps {
  title: string;
  userRole: string;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ title, userRole, onLogout }) => {
  const [search, setSearch] = useState('');

  return (
    <header className="nn-topbar">
      <div className="nn-topbar-title">
        <div className="nn-breadcrumb"><span>NEURONEXUS</span><i>/</i><span>Clinical Workspace</span></div>
        <h1>{title}</h1>
      </div>

      <div className="nn-topbar-actions">
        <div className="nn-command-search">
          <span>⌕</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search patients, modules, records…" />
          <kbd>⌘ K</kbd>
        </div>
        <button className="nn-icon-button" title="Notifications" aria-label="Notifications"><span>◌</span><b>3</b></button>
        <button className="nn-icon-button" title="AI Copilot" aria-label="AI Copilot">✦</button>
        <div className="nn-user-menu">
          <div className="nn-avatar">{(userRole || 'U').slice(0,1).toUpperCase()}</div>
          <div className="nn-user-meta"><strong>{userRole}</strong><span><i /> Secure session</span></div>
          <button className="nn-logout" onClick={onLogout} title="Logout">↗</button>
        </div>
      </div>
    </header>
  );
};
