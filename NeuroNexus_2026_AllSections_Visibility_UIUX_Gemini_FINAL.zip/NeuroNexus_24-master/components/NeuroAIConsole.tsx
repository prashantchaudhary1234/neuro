import React, { useMemo, useState } from 'react';
import { askClinicalAI } from '../services/geminiService';

interface NeuroAIConsoleProps {
  role: string;
  context?: Record<string, unknown>;
  title?: string;
  subtitle?: string;
}

export const NeuroAIConsole: React.FC<NeuroAIConsoleProps> = ({
  role,
  context = {},
  title = 'Neuro AI Assistant',
  subtitle = 'Ask a workflow question and get a live Gemini response.'
}) => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const quickPrompts = useMemo(() => {
    const common = ['Summarize the current workflow', 'What should I review next?', 'Highlight important items'];
    if (role === 'Doctor') return ['Summarize my current patient workload', 'What should I review next for these patients?', 'Explain the main clinical priorities'];
    if (role === 'Nurse') return ['Summarize current bed and admission status', 'What should the nursing team review next?', 'Highlight patients needing attention'];
    if (role === 'Receptionist') return ['Summarize today’s appointment workflow', 'What should reception review next?', 'Highlight registration or scheduling issues'];
    if (role === 'Intern') return ['Summarize the current patient queue', 'What should I prepare before assessment?', 'Highlight items to discuss with the supervising doctor'];
    if (role === 'Admin') return ['Summarize hospital operations from the supplied data', 'What operational items should I review next?', 'Highlight workflow bottlenecks'];
    return common;
  }, [role]);

  const submit = async (prompt = question) => {
    const trimmed = prompt.trim();
    if (!trimmed || loading) return;
    setLoading(true);
    setError('');
    setAnswer('');
    try {
      const result = await askClinicalAI({
        question: trimmed,
        patient: {
          role,
          dashboardContext: context,
        },
      });
      setAnswer(result.answer || 'No response was returned.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gemini request failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="nn-ai-console" aria-label={`${role} Neuro AI Assistant`}>
      <div className="nn-ai-console-glow" aria-hidden="true" />
      <div className="nn-ai-console-head">
        <div className="nn-ai-console-icon">✦</div>
        <div>
          <div className="nn-ai-console-kicker">LIVE GEMINI INTELLIGENCE · {role.toUpperCase()}</div>
          <h2>{title}</h2>
          <p>{subtitle}</p>
        </div>
        <span className="nn-ai-online"><i /> API READY</span>
      </div>

      <div className="nn-ai-quick-row">
        {quickPrompts.map(prompt => (
          <button key={prompt} type="button" onClick={() => { setQuestion(prompt); void submit(prompt); }} disabled={loading}>
            {prompt}
          </button>
        ))}
      </div>

      <div className="nn-ai-console-body">
        <div className="nn-ai-answer">
          {loading ? (
            <div className="nn-ai-loading"><span /><span /><span /> Gemini is analyzing the supplied dashboard context…</div>
          ) : error ? (
            <div className="nn-ai-error"><strong>Gemini request failed</strong><br />{error}<small>Check GEMINI_API_KEY and the deployed /api/ai/ask endpoint.</small></div>
          ) : answer ? (
            <div className="nn-ai-response"><span className="nn-ai-response-label">LIVE RESULT</span>{answer}</div>
          ) : (
            <div className="nn-ai-empty">Ask a question to receive a real Gemini response. The assistant only receives the workflow context supplied by this dashboard.</div>
          )}
        </div>
      </div>

      <form className="nn-ai-input-row" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
        <input value={question} onChange={e => setQuestion(e.target.value)} placeholder="Ask Neuro AI about this dashboard…" aria-label="Ask Neuro AI" />
        <button type="submit" disabled={loading || !question.trim()}>{loading ? '…' : 'Ask AI →'}</button>
      </form>
      <div className="nn-ai-disclaimer">AI decision support only. Verify important information with appropriate clinical or administrative staff.</div>
    </section>
  );
};
