import React, { useState } from 'react';

const SettingRow: React.FC<{
    title: string;
    description: string;
    enabled: boolean;
    onChange: (value: boolean) => void;
    tone?: 'cyan' | 'violet' | 'green';
}> = ({ title, description, enabled, onChange, tone = 'cyan' }) => (
    <div className="nn-setting-row">
        <div className="nn-setting-copy">
            <strong>{title}</strong>
            <span>{description}</span>
        </div>
        <button
            type="button"
            className={`nn-toggle nn-toggle-${tone} ${enabled ? 'is-on' : ''}`}
            onClick={() => onChange(!enabled)}
            aria-pressed={enabled}
            aria-label={`${title}: ${enabled ? 'on' : 'off'}`}
        >
            <span />
        </button>
    </div>
);

export const SettingsView: React.FC = () => {
    const [liveSync, setLiveSync] = useState(true);
    const [clinicalAlerts, setClinicalAlerts] = useState(true);
    const [aiSuggestions, setAiSuggestions] = useState(true);
    const [sound, setSound] = useState(false);

    return (
        <div className="nn-settings-page">
            <section className="nn-settings-hero">
                <div>
                    <div className="nn-settings-eyebrow">NEURONEXUS / SYSTEM CONTROL</div>
                    <h2>Settings</h2>
                    <p>Configure your clinical workspace, notifications and AI experience.</p>
                </div>
                <div className="nn-settings-health">
                    <span className="nn-live-pulse" />
                    <div><strong>System Online</strong><small>All services synchronized</small></div>
                </div>
            </section>

            <div className="nn-settings-grid">
                <section className="nn-settings-card nn-settings-card-wide">
                    <div className="nn-settings-card-head">
                        <div><span className="nn-settings-icon">◈</span><div><h3>User Preferences</h3><p>Personalize how NeuroNexus behaves during clinical work.</p></div></div>
                        <span className="nn-settings-badge">ACTIVE</span>
                    </div>
                    <SettingRow title="Real-time clinical sync" description="Keep ward telemetry and patient status synchronized." enabled={liveSync} onChange={setLiveSync} tone="cyan" />
                    <SettingRow title="Clinical alert notifications" description="Show high-priority ICU alerts immediately in the workspace." enabled={clinicalAlerts} onChange={setClinicalAlerts} tone="green" />
                    <SettingRow title="Neuro AI suggestions" description="Allow Gemini-powered clinical summaries and explanations." enabled={aiSuggestions} onChange={setAiSuggestions} tone="violet" />
                    <SettingRow title="Interface sounds" description="Play subtle sounds for new alerts and system events." enabled={sound} onChange={setSound} tone="cyan" />
                </section>

                <section className="nn-settings-card">
                    <div className="nn-settings-card-head simple"><div><span className="nn-settings-icon violet">✦</span><div><h3>AI Copilot</h3><p>Gemini integration status</p></div></div></div>
                    <div className="nn-ai-status-large"><span className="nn-live-pulse" /><div><strong>Gemini Connected</strong><small>Backend AI service is configured</small></div></div>
                    <div className="nn-settings-metric"><span>Model</span><b>Gemini 2.5 Flash</b></div>
                    <div className="nn-settings-metric"><span>Connection</span><b className="good">READY</b></div>
                </section>

                <section className="nn-settings-card">
                    <div className="nn-settings-card-head simple"><div><span className="nn-settings-icon">⌁</span><div><h3>System Health</h3><p>Current application services</p></div></div></div>
                    <div className="nn-health-list">
                        <div><span>API Gateway</span><b className="good">Operational</b></div>
                        <div><span>ICU Telemetry</span><b className="good">Live</b></div>
                        <div><span>AI Engine</span><b className="good">Ready</b></div>
                        <div><span>Database</span><b className="good">Synced</b></div>
                    </div>
                </section>
            </div>
        </div>
    );
};
