import React, { useMemo, useState } from 'react';
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { ClinicalIntelligenceService } from '../../services/clinicalIntelligenceService';
import { AlertEngine } from '../../services/alertEngine';
import type { ICUPatientRecord } from '../../types';
import {
  analyzeICUPatient,
  generateClinicalSummary,
  explainICUAlert,
} from '../../services/geminiService';
import './ICUWardCommandCenter.css';

type Status = 'STABLE' | 'ATTENTION' | 'CRITICAL';

interface ICUWardCommandCenterProps {
  onSelectPatient: (patientId: string) => void;
  onLaunchReplay: (patientId?: string) => void;
  onNavigateTab?: (viewId: string) => void;
}

interface BedTelemetry {
  id: string;
  patient: ICUPatientRecord;
  status: Status;
  heartRate: number;
  systolic: number;
  diastolic: number;
  spo2: number;
  respiratoryRate: number;
  temperature: number;
  trend: { time: string; hr: number; bp: number; spo2: number; rr: number }[];
}

const bedPositions = [
  { left: '11%', top: '22%' },
  { left: '39%', top: '16%' },
  { left: '68%', top: '23%' },
  { left: '20%', top: '57%' },
  { left: '50%', top: '53%' },
  { left: '77%', top: '58%' },
];

const getStatus = (patient: ICUPatientRecord): Status => {
  if (patient.final_severity === 'CRITICAL') return 'CRITICAL';
  if (patient.final_severity === 'HIGH' || patient.final_severity === 'MONITOR') return 'ATTENTION';
  return 'STABLE';
};

const latest = (patient: ICUPatientRecord, parameter: string, fallback: number) => {
  const matches = patient.observations.filter(o => o.parameter === parameter && Number.isFinite(o.value));
  return matches.length ? matches[matches.length - 1].value : fallback;
};

const makeTelemetry = (patient: ICUPatientRecord, index: number): BedTelemetry => {
  const heartRate = latest(patient, 'HR', 78 + index * 4);
  const systolic = latest(patient, 'NISysABP', 118 - index * 4);
  const diastolic = latest(patient, 'NIDiasABP', 72 - index * 2);
  const spo2 = latest(patient, 'SaO2', latest(patient, 'SpO2', 96 - index * 0.5));
  const respiratoryRate = latest(patient, 'RespRate', 16 + (index % 3));
  const temperature = latest(patient, 'Temp', 36.8 + index * 0.15);
  const points = patient.trajectory.slice(-18).map((p, i) => ({
    time: `${Math.max(0, p.time_hours - 17 + i).toFixed(0)}h`,
    hr: Math.round(heartRate + Math.sin(i / 2) * 4 + (p.risk_score - patient.final_risk_score) * 12),
    bp: Math.round(systolic + Math.cos(i / 3) * 4),
    spo2: Number(Math.min(100, Math.max(88, spo2 + Math.sin(i / 2.5) * 0.7)).toFixed(1)),
    rr: Number(Math.max(8, respiratoryRate + Math.sin(i / 2) * 1.5).toFixed(0)),
  }));
  return {
    id: `ICU-BAY-${String(index + 1).padStart(2, '0')}`,
    patient,
    status: getStatus(patient),
    heartRate: Math.round(heartRate),
    systolic: Math.round(systolic),
    diastolic: Math.round(diastolic),
    spo2: Number(spo2.toFixed(1)),
    respiratoryRate: Math.round(respiratoryRate),
    temperature: Number(temperature.toFixed(1)),
    trend: points.length ? points : [{ time: 'now', hr: Math.round(heartRate), bp: Math.round(systolic), spo2, rr: Math.round(respiratoryRate) }],
  };
};

const statusLabel = (status: Status) => status === 'ATTENTION' ? 'ATTENTION' : status;

const displayNames = ['Prashant', 'Aarav', 'Ananya', 'Rohan', 'Maya', 'Vikram'];
const displayNameForBed = (bedId: string) => {
  const match = bedId.match(/(\d+)$/);
  const index = match ? Math.max(0, Number(match[1]) - 1) : 0;
  return displayNames[index % displayNames.length];
};

const Sparkline = ({ values }: { values: number[] }) => (
  <svg viewBox="0 0 100 28" className="sparkline" preserveAspectRatio="none" aria-hidden="true">
    <polyline
      points={values.map((v, i) => `${(i / Math.max(1, values.length - 1)) * 100},${28 - ((v - Math.min(...values)) / Math.max(1, Math.max(...values) - Math.min(...values))) * 22}`).join(' ')}
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      vectorEffect="non-scaling-stroke"
    />
  </svg>
);

const BedModel = ({ selected, telemetry, onClick }: { selected: boolean; telemetry: BedTelemetry; onClick: () => void }) => (
  <button className={`ward-bed ${selected ? 'is-selected' : ''}`} onClick={onClick} aria-label={`Select ${telemetry.id}`}>
    <span className={`bed-status bed-status-${telemetry.status.toLowerCase()}`}></span>
    <span className="bed-label">
      <strong>{telemetry.id}</strong>
      <small>{statusLabel(telemetry.status)}</small>
    </span>
    <span className="bed-body">
      <span className="bed-headboard"></span>
      <span className="bed-mattress"><span className="bed-pillow"></span></span>
      <span className="bed-rail bed-rail-left"></span>
      <span className="bed-rail bed-rail-right"></span>
      <span className="bed-frame"></span>
      <span className="bed-wheel wheel-1"></span><span className="bed-wheel wheel-2"></span>
      <span className="bed-monitor"><span></span></span>
    </span>
  </button>
);

export const ICUWardCommandCenter: React.FC<ICUWardCommandCenterProps> = ({
  onSelectPatient,
  onLaunchReplay,
  onNavigateTab,
}) => {
  const patients = useMemo(() => ClinicalIntelligenceService.getPatients().slice(0, 6), []);
  const beds = useMemo(() => patients.map((p, i) => makeTelemetry(p, i)), [patients]);
  const [selectedId, setSelectedId] = useState(beds[0]?.id || '');
  const [orbit, setOrbit] = useState(false);
  const [viewMode, setViewMode] = useState<'2D' | '3D'>('3D');
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const dragState = React.useRef({ active: false, moved: false, x: 0, y: 0, startX: 0, startY: 0 });
  const [aiLoading, setAiLoading] = useState(false);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);
  const [summary, setSummary] = useState('');
  const [aiError, setAiError] = useState('');
  const [search, setSearch] = useState('');
  const [backendOnline, setBackendOnline] = useState(false);
  const [geminiConfigured, setGeminiConfigured] = useState(false);

  const startFullOrbit = () => {
    setOrbit(false);
    window.requestAnimationFrame(() => setOrbit(true));
  };

  const handleWardPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0 || viewMode !== '3D' || orbit) return;
    dragState.current = {
      active: true, moved: false, x: event.clientX, y: event.clientY,
      startX: event.clientX, startY: event.clientY,
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };

  const handleWardPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const state = dragState.current;
    if (!state.active || viewMode !== '3D' || orbit) return;
    const dx = event.clientX - state.x;
    const dy = event.clientY - state.y;
    if (Math.abs(event.clientX - state.startX) + Math.abs(event.clientY - state.startY) > 6) state.moved = true;
    state.x = event.clientX;
    state.y = event.clientY;
    setRotation(current => ({
      x: Math.max(-18, Math.min(18, current.x - dy * 0.18)),
      y: current.y + dx * 0.28,
    }));
  };

  const handleWardPointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    const moved = dragState.current.moved;
    dragState.current.active = false;
    try { event.currentTarget.releasePointerCapture?.(event.pointerId); } catch {}
    if (moved) window.setTimeout(() => { dragState.current.moved = false; }, 0);
  };

  const handleWardClickCapture = (event: React.MouseEvent<HTMLDivElement>) => {
    if (dragState.current.moved) {
      event.preventDefault();
      event.stopPropagation();
      dragState.current.moved = false;
    }
  };

  const handleWardWheel = (event: React.WheelEvent<HTMLDivElement>) => {
    if (viewMode !== '3D' || orbit) return;
    event.preventDefault();
    const delta = event.deltaY > 0 ? -0.06 : 0.06;
    setZoom(value => Math.max(0.78, Math.min(1.45, Number((value + delta).toFixed(2)))));
  };

  React.useEffect(() => {
    let cancelled = false;
    const checkBackend = async () => {
      try {
        const response = await fetch('/api/health');
        const data = await response.json();
        if (!cancelled) {
          setBackendOnline(Boolean(data.ok));
          setGeminiConfigured(Boolean(data.geminiConfigured));
        }
      } catch {
        if (!cancelled) {
          setBackendOnline(false);
          setGeminiConfigured(false);
        }
      }
    };
    checkBackend();
    const timer = window.setInterval(checkBackend, 15000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, []);

  const selected = beds.find(b => b.id === selectedId) || beds[0];
  const metrics = useMemo(() => ({
    beds: beds.length,
    critical: beds.filter(b => b.status === 'CRITICAL').length,
    attention: beds.filter(b => b.status === 'ATTENTION').length,
    stable: beds.filter(b => b.status === 'STABLE').length,
  }), [beds]);

  const selectBed = (bed: BedTelemetry) => {
    setSelectedId(bed.id);
    setAiResult(null);
    setSummary('');
    setAiError('');
  };

  const analyze = async () => {
    if (!selected) return;
    setAiLoading(true);
    setAiError('');
    try {
      const result = await analyzeICUPatient({
        patientId: selected.patient.record_id,
        bedId: selected.id,
        age: selected.patient.age,
        gender: selected.patient.gender,
        icuType: selected.patient.icu_type,
        diagnosis: 'ICU monitoring case',
        riskScore: selected.patient.final_risk_score,
        severity: selected.patient.final_severity,
        vitals: {
          heartRate: selected.heartRate,
          bloodPressure: `${selected.systolic}/${selected.diastolic}`,
          spo2: selected.spo2,
          respiratoryRate: selected.respiratoryRate,
          temperature: selected.temperature,
        },
        contributingSignals: selected.patient.trajectory.at(-1)?.contributing_signals || [],
      });
      setAiResult(result);
    } catch (error) {
      setAiError(error instanceof Error ? error.message : 'Gemini analysis failed.');
    } finally {
      setAiLoading(false);
    }
  };

  const createSummary = async () => {
    if (!selected) return;
    setSummaryLoading(true);
    setAiError('');
    try {
      const result = await generateClinicalSummary({
        patientId: selected.patient.record_id,
        bedId: selected.id,
        age: selected.patient.age,
        gender: selected.patient.gender,
        icuType: selected.patient.icu_type,
        riskScore: selected.patient.final_risk_score,
        severity: selected.patient.final_severity,
        vitals: {
          heartRate: selected.heartRate,
          bloodPressure: `${selected.systolic}/${selected.diastolic}`,
          spo2: selected.spo2,
          respiratoryRate: selected.respiratoryRate,
          temperature: selected.temperature,
        },
      });
      setSummary(result.summary || result.text || 'No summary returned.');
    } catch (error) {
      setAiError(error instanceof Error ? error.message : 'Clinical summary failed.');
    } finally {
      setSummaryLoading(false);
    }
  };

  const explainAlert = async () => {
    if (!selected) return;
    setAiLoading(true);
    setAiError('');
    try {
      const alerts = AlertEngine.getStoredAlerts();
      const alert = alerts.find(a => a.patientId === selected.patient.record_id);
      if (!alert) {
        setAiResult({ summary: 'No stored alert exists for this patient.', riskScore: selected.patient.final_risk_score * 100, keyFactors: [] });
        return;
      }
      const result = await explainICUAlert({
        bedId: selected.id,
        patientId: selected.patient.record_id,
        severity: alert.severity,
        riskScore: alert.riskScore,
        explanation: alert.explanation,
        contributingSignals: alert.contributingSignals.map(s => s.signal),
      });
      setAiResult(result);
    } catch (error) {
      setAiError(error instanceof Error ? error.message : 'Alert explanation failed.');
    } finally {
      setAiLoading(false);
    }
  };

  if (!selected) return <div className="nn-empty-state">No ICU telemetry is available.</div>;

  return (
    <div className="nn-command-center">
      <aside className="nn-command-sidebar">
        <div className="nn-brand">
          <div className="nn-brand-mark">N</div>
          <div><strong>NEURONEXUS</strong><span>ICU CLINICAL INTELLIGENCE</span></div>
        </div>
        <div className="nn-nav-label">ICU & CLINICAL INTELLIGENCE</div>
        <button className="nn-nav-item active"><span>▣</span>3D ICU Ward</button>
        <button className="nn-nav-item" onClick={() => onNavigateTab?.('ci_icu_warning')}><span>⌁</span>ICU Early Warning System</button>
        <button className="nn-nav-item" onClick={() => onLaunchReplay()}><span>◷</span>Chronological Patient Replay</button>
        <button className="nn-nav-item" onClick={() => onNavigateTab?.('ci_alerts')}><span>△</span>Alert Center & Audit Log</button>
        <div className="nn-nav-divider" />
        <div className="nn-nav-label">CORE CLINICAL OPERATIONS</div>
        <button className="nn-nav-item" onClick={() => onNavigateTab?.('triage')}><span>✚</span>Emergency & Triage Queue</button>
        <button className="nn-nav-item" onClick={() => onNavigateTab?.('dashboard')}><span>♙</span>Active Patients & Vitals</button>
        <button className="nn-nav-item" onClick={() => onNavigateTab?.('module_5')}><span>▤</span>Consultation & E-Prescriptions</button>
        <button className="nn-nav-item" onClick={() => onNavigateTab?.('module_32')}><span>▥</span>Discharge Summary Management</button>
        <div className="nn-system-status">
          <div className="nn-system-title"><span className="live-dot"></span>System Status <span>⚙</span></div>
          <strong>All Systems Operational</strong>
          <div className="nn-system-row"><span>ICU Beds Online</span><b>{metrics.beds} / {metrics.beds}</b></div>
          <div className="nn-system-row"><span>Data Pipeline</span><b>Active</b></div>
          <div className="nn-system-row"><span>AI Models</span><b>Online</b></div>
          <div className="nn-system-row"><span>Backend API</span><b className="nn-backend-dot">{backendOnline ? 'Connected' : 'Offline'}</b></div>
          <div className="nn-system-row"><span>Gemini AI</span><b className={geminiConfigured ? 'nn-backend-dot' : 'nn-backend-warn'}>{geminiConfigured ? 'Ready' : 'Configure Key'}</b></div>
        </div>
      </aside>

      <main className="nn-command-main">
        <header className="nn-command-header">
          <div className="nn-header-title"><span className="header-pulse">⌁</span><div><div className="eyebrow">CLINICAL INTELLIGENCE COMMAND CENTER</div><h1>3D ICU Ward • Real-Time Digital Twin</h1></div></div>
          <div className="nn-header-actions">
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search patient, bed, or ID..." />
            <button className="header-outline" onClick={() => onNavigateTab?.('ci_alerts')}>♧ <span>Doctors Roster</span></button>
            <button className="green-action" onClick={() => onNavigateTab?.('module_1')}>＋ Register Patient</button>
            <button className="icon-action" aria-label="Notifications">♧</button>
            <div className="nn-profile"><span className="live-dot"></span><div><b>Chief Medical Officer</b><small>Active Session</small></div><strong>C</strong></div>
            <button className="icon-action" onClick={() => onNavigateTab?.('settings')}>↪</button>
          </div>
        </header>

        <section className="nn-content">
          <div className="nn-ward-card">
            <div className="nn-ward-heading">
              <div><h2>3D ICU Ward Twin • Real-Time Bed Telemetry</h2><p>Interactive digital twin of hospital ICU beds. Click any bed to inspect live vitals or adjust acuity.</p></div>
              <span className="sync-pill">◉ SYNCHRONIZED WITH CENTRAL DB</span>
            </div>
            <div className="nn-kpis">
              <div><span>▣</span><b>ICU Beds: <em>{metrics.beds}</em></b></div>
              <div className="critical"><span>△</span><b>Critical: <em>{metrics.critical}</em></b></div>
              <div className="attention"><span>⌁</span><b>Attention: <em>{metrics.attention}</em></b></div>
              <div className="stable"><span>✓</span><b>Stable: <em>{metrics.stable}</em></b></div>
              <button className="primary-action" onClick={() => onNavigateTab?.('module_1')}>♙ Add Patient</button>
              <button className="outline-action" onClick={startFullOrbit}>◌ {orbit ? 'Orbiting 360°…' : '360° Orbit'}</button>
            </div>

            <div className={`nn-ward-stage ${orbit ? 'orbiting' : ''} ${viewMode === '2D' ? 'flat-view' : ''}`} onAnimationEnd={(event) => { if (event.target === event.currentTarget) setOrbit(false); }} onPointerDown={handleWardPointerDown} onPointerMove={handleWardPointerMove} onPointerUp={handleWardPointerUp} onPointerCancel={handleWardPointerUp} onWheel={handleWardWheel} onClickCapture={handleWardClickCapture}>
              <div className="ward-ceiling-glow"></div>
              <div className="ward-3d-world" style={{ ['--ward-zoom' as string]: zoom, ['--ward-rotate-x' as string]: `${rotation.x}deg`, ['--ward-rotate-y' as string]: `${rotation.y}deg` }}>
                <div className="ward-room-backdrop">
                  <div className="ward-window"></div>
                  <div className="ward-ceiling-light light-a"></div><div className="ward-ceiling-light light-b"></div><div className="ward-ceiling-light light-c"></div>
                  <div className="ward-monitor-wall"><span></span><span></span><span></span></div>
                  <div className="ward-nurse-station"><i></i><i></i><i></i></div>
                  <div className="ward-glass-divider divider-a"></div><div className="ward-glass-divider divider-b"></div>
                </div>
                <div className="ward-floor" style={{ transform: viewMode === '2D' ? 'rotateX(8deg)' : 'rotateX(60deg)' }}>
                  {Array.from({ length: 12 }).map((_, i) => <span key={`h${i}`} className="grid-line h" style={{ top: `${i * 9}%` }} />)}
                  {Array.from({ length: 13 }).map((_, i) => <span key={`v${i}`} className="grid-line v" style={{ left: `${i * 8.3}%` }} />)}
                  {beds.map((bed, i) => {
                    const matchesSearch = !search || bed.id.toLowerCase().includes(search.toLowerCase()) || bed.patient.record_id.includes(search);
                    if (!matchesSearch) return null;
                    return <div key={bed.id} className="bed-position" style={bedPositions[i]}><BedModel selected={bed.id === selected.id} telemetry={bed} onClick={() => selectBed(bed)} /></div>;
                  })}
                </div>
              </div>
              <div className="ward-map-card">
                <div className="ward-map-title">ICU Ward Map <span>⌖</span></div>
                <div className="ward-mini-map">
                  {beds.map((bed, i) => <span key={bed.id} className={`map-dot ${bed.status.toLowerCase()} ${bed.id === selected.id ? 'selected' : ''}`} style={{ left: `${16 + (i % 3) * 34}%`, top: `${22 + Math.floor(i / 3) * 42}%` }} />)}
                </div>
                <div className="ward-map-legend"><span><i className="stable"></i>Stable</span><span><i className="attention"></i>Attention</span><span><i className="critical"></i>Critical</span></div>
              </div>
              <div className="ward-controls"><button aria-label="Zoom in" onClick={() => setZoom(v => Math.min(1.45, Number((v + 0.08).toFixed(2))))}>＋</button><button aria-label="Zoom out" onClick={() => setZoom(v => Math.max(0.85, Number((v - 0.08).toFixed(2))))}>−</button><button aria-label="Reset" onClick={() => { setOrbit(false); setZoom(1); setRotation({ x: 0, y: 0 }); setViewMode('3D'); }}>◎</button></div>
              <div className="ward-interaction-hint">↔ Drag to rotate • ↕ Tilt • Scroll to zoom</div><div className="ward-view-toggle"><button className={viewMode === '2D' ? 'selected' : ''} onClick={() => { setViewMode('2D'); setOrbit(false); }}>2D View</button><button className={viewMode === '3D' ? 'selected' : ''} onClick={() => setViewMode('3D')}>3D View</button><button onClick={() => { setOrbit(false); setZoom(1); setRotation({ x: 0, y: 0 }); setViewMode('3D'); }}>⟳ Reset View</button></div>
            </div>
          </div>

          <aside className="nn-patient-panel">
            <div className="patient-panel-top">
              <div>
                <div className="patient-top-line"><span className="patient-id">{selected.id}</span><span className="bay-name">• Bay {selected.id.replace('ICU-BAY-', '')} / North ICU</span><span className={`status-badge ${selected.status.toLowerCase()}`}>{statusLabel(selected.status)}</span></div>
                <h2>{displayNameForBed(selected.id)}</h2>
                <p>{selected.patient.age} yrs • Adult • Dr. Evelyn Reed</p>
              </div>
              <div className="patient-live-stack"><span className={`attention-chip ${selected.status.toLowerCase()}`}>{selected.status === 'STABLE' ? 'STABLE' : 'REQUIRES ATTENTION'}</span><span className="live-chip"><i></i> LIVE</span></div>
            </div>
            <div className="diagnosis-box"><span>PRIMARY ADMITTING DIAGNOSIS</span><strong>{selected.id === 'ICU-BAY-06' ? 'Fever' : 'ICU monitoring'}</strong><small>Record #{selected.patient.record_id} • {selected.patient.icu_type}</small></div>
            <div className="risk-box"><div><span>🧠 AI Deterioration Risk Index</span><strong>{Math.round(selected.patient.final_risk_score * 100)}%</strong></div><div className="risk-bar"><i style={{ width: `${Math.round(selected.patient.final_risk_score * 100)}%` }} /></div></div>

            <div className="vitals-grid">
              <div className="vital-card hr"><span>♡ HEART RATE</span><strong>{selected.heartRate}<small>bpm</small></strong><Sparkline values={selected.trend.map(p => p.hr)} /></div>
              <div className="vital-card bp"><span>⌁ BLOOD PRESSURE</span><strong>{selected.systolic}/{selected.diastolic}<small>mmHg</small></strong><Sparkline values={selected.trend.map(p => p.bp)} /></div>
              <div className="vital-card oxygen"><span>◌ SPO₂ OXYGEN</span><strong>{selected.spo2}<small>%</small></strong><Sparkline values={selected.trend.map(p => p.spo2)} /></div>
              <div className="vital-card resp"><span>♧ RESPIRATORY RATE</span><strong>{selected.respiratoryRate}<small>/min</small></strong><Sparkline values={selected.trend.map(p => p.rr)} /></div>
              <div className="vital-card temp"><span>♨ TEMPERATURE</span><strong>{selected.temperature}<small>°C</small></strong></div>
            </div>

            <div className="trend-card">
              <div className="trend-heading"><div><span>Live Vitals Trend</span><small>Last 2 Hours</small></div><select><option>Heart Rate</option><option>Blood Pressure</option><option>SpO₂</option></select></div>
              <div className="chart-wrap"><ResponsiveContainer width="100%" height={150}><AreaChart data={selected.trend}><defs><linearGradient id="nnHrFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#00d9ff" stopOpacity={0.25}/><stop offset="100%" stopColor="#00d9ff" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#16304a" vertical={false}/><XAxis dataKey="time" stroke="#607b94" tick={{ fontSize: 9 }}/><YAxis stroke="#607b94" tick={{ fontSize: 9 }} width={28}/><Tooltip contentStyle={{ background: '#071524', border: '1px solid #194362', borderRadius: 10, color: '#fff' }}/><Area type="monotone" dataKey="hr" stroke="#00d9ff" fill="url(#nnHrFill)" strokeWidth={2.5}/></AreaChart></ResponsiveContainer></div>
              <div className="legend"><span><i className="cyan"></i>HR (bpm)</span><span><i className="blue"></i>BP (mmHg)</span><span><i className="green"></i>SpO₂ (%)</span><span><i className="purple"></i>RR (/min)</span></div>
            </div>

            <div className="ai-panel">
              <div className="ai-title"><div><span>✦ AI Clinical Decision Support</span><small>Gemini-powered • server-side API</small></div><span className={`ai-online ${geminiConfigured ? '' : 'offline'}`}>● {geminiConfigured ? 'ONLINE' : 'OFFLINE'}</span></div>
              <div className="ai-buttons"><button onClick={analyze} disabled={aiLoading}>{aiLoading ? 'Analyzing…' : 'Analyze with Gemini'}</button><button onClick={createSummary} disabled={summaryLoading}>{summaryLoading ? 'Generating…' : 'Clinical Summary'}</button><button onClick={explainAlert} disabled={aiLoading}>Why flagged?</button></div>
              {aiError && <div className="ai-error">{aiError}</div>}
              {aiResult && <div className="ai-result"><strong>{aiResult.summary || aiResult.explanation || 'AI analysis returned.'}</strong>{Array.isArray(aiResult.keyFactors) && aiResult.keyFactors.length > 0 && <ul>{aiResult.keyFactors.map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>}</div>}
              {summary && <div className="ai-summary">{summary}</div>}
              <p className="ai-disclaimer">Decision support only. Gemini does not make autonomous diagnoses or treatment decisions.</p>
            </div>

            <button className="replay-button" onClick={() => onLaunchReplay(selected.patient.record_id)}>▶ Launch chronological replay</button>
          </aside>
        </section>
      </main>
    </div>
  );
};
