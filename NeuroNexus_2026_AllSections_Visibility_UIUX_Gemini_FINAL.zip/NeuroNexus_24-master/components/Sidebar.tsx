import React, { useState } from 'react';
import type { View, NavItemType } from '../types';
import { navStructure } from '../navigation';
import { ChevronDownIcon } from './icons';

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

const NavItem: React.FC<{
  item: NavItemType;
  isActive: boolean;
  collapsed: boolean;
  onClick: () => void;
}> = ({ item, isActive, collapsed, onClick }) => {
  const { icon: Icon, label } = item;
  return (
    <li>
      <button
        onClick={onClick}
        className={`nn-nav-item ${isActive ? 'is-active' : ''} ${collapsed ? 'is-collapsed' : ''}`}
        title={collapsed ? label : undefined}
        aria-label={label}
      >
        <span className="nn-nav-icon"><Icon className="w-5 h-5" /></span>
        {!collapsed && <span className="nn-nav-label">{label}</span>}
        {!collapsed && isActive && <span className="nn-nav-active-dot" />}
      </button>
    </li>
  );
};

const NavCategory: React.FC<{
  category: string;
  icon: React.ElementType;
  collapsed: boolean;
  children: React.ReactNode;
}> = ({ category, icon: Icon, collapsed, children }) => {
  const [isOpen, setIsOpen] = useState(true);

  if (collapsed) {
    return <div className="nn-sidebar-collapsed-group"><span className="nn-category-icon" title={category}><Icon className="w-4 h-4" /></span>{children}</div>;
  }

  return (
    <div className="nn-nav-category">
      <button className="nn-nav-category-head" onClick={() => setIsOpen(!isOpen)}>
        <span><Icon className="w-4 h-4" />{category}</span>
        <ChevronDownIcon className={`w-3.5 h-3.5 ${isOpen ? '' : '-rotate-90'}`} />
      </button>
      {isOpen && <div className="nn-nav-category-items">{children}</div>}
    </div>
  );
};

export const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside className={`nn-sidebar ${collapsed ? 'is-collapsed' : ''}`}>
      <div className="nn-sidebar-brand">
        <div className="nn-brand-mark"><span>✦</span></div>
        {!collapsed && (
          <div className="nn-brand-copy">
            <strong>NEURONEXUS</strong>
            <span>Clinical OS</span>
          </div>
        )}
        <button className="nn-sidebar-toggle" onClick={() => setCollapsed(v => !v)} aria-label="Toggle sidebar">
          {collapsed ? '›' : '‹'}
        </button>
      </div>

      {!collapsed && (
        <div className="nn-sidebar-status">
          <span className="nn-live-pulse" />
          <div><b>System Online</b><small>All clinical services synced</small></div>
          <span className="nn-status-chip">LIVE</span>
        </div>
      )}

      <nav className="nn-sidebar-nav">
        {navStructure.map(({ category, icon, items }) => (
          <NavCategory key={category} category={category} icon={icon} collapsed={collapsed}>
            <ul className="nn-nav-list">
              {items.map(item => (
                <NavItem
                  key={item.id}
                  item={item}
                  isActive={activeView === item.id}
                  collapsed={collapsed}
                  onClick={() => setActiveView(item.id)}
                />
              ))}
            </ul>
          </NavCategory>
        ))}
      </nav>

      {!collapsed && (
        <div className="nn-sidebar-footer">
          <div className="nn-ai-orb">✦</div>
          <div><b>Neuro AI</b><span>Clinical copilot ready</span></div>
          <span className="nn-ai-dot" />
        </div>
      )}
    </aside>
  );
};
