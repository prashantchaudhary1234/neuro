$ErrorActionPreference = 'Stop'
Write-Host '=== NeuroNexus Clinical Intelligence ===' -ForegroundColor Cyan
if (-not (Test-Path '.env')) {
  Write-Host 'No .env found. Run: node scripts/setup-gemini.mjs' -ForegroundColor Yellow
}
Write-Host 'Starting Gemini backend on http://localhost:8787 ...' -ForegroundColor Green
Start-Process powershell -ArgumentList '-NoExit','-Command','npm run server'
Start-Sleep -Seconds 2
Write-Host 'Starting React frontend on http://localhost:3000 ...' -ForegroundColor Green
npm run dev
