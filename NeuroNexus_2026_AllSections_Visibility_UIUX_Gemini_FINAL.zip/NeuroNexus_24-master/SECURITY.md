# Security and deployment notes

## API keys

Gemini API credentials are intentionally not distributed in this project archive. Configure the key locally with:

```bash
node scripts/setup-gemini.mjs
```

or by creating `.env` from `.env.example`.

## Clinical data

Do not use real patient-identifiable information in this academic/demo project. Replace mock/curated data with a properly secured clinical data layer before any real-world deployment.

## AI output

Gemini responses are generated as clinical decision support. They are not autonomous diagnosis or treatment instructions and require qualified clinician review.

## Production hardening

Before production deployment, add authenticated sessions, authorization checks, audit logging, encrypted transport, secret management, rate limiting, request validation, database controls, secure headers, monitoring, and a formal privacy/security review.
